
package com.example.weatherapp

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient()
    private lateinit var weatherTextView: TextView
    private lateinit var cityInput: EditText
    private lateinit var historyList: ListView
    private val cityHistory = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        weatherTextView = findViewById(R.id.weatherTextView)
        cityInput = findViewById(R.id.cityInput)
        historyList = findViewById(R.id.historyList)

        val searchButton: Button = findViewById(R.id.searchButton)
        searchButton.setOnClickListener {
            val city = cityInput.text.toString()
            if (city.isNotBlank()) {
                fetchWeatherData(city)
                cityHistory.add(city)
                updateHistory()
            }
        }
    }

    private fun fetchWeatherData(city: String) {
        val apiKey = "your_api_key_here"  // Replace with your API key
        val url = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric"

        val request = Request.Builder().url(url).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { weatherTextView.text = "Failed to load data" }
            }

            override fun onResponse(call: Call, response: Response) {
                val jsonData = response.body?.string()
                if (jsonData != null) {
                    val weatherInfo = JSONObject(jsonData)
                    val temp = weatherInfo.getJSONObject("main").getDouble("temp")
                    val description = weatherInfo.getJSONArray("weather").getJSONObject(0).getString("description")

                    runOnUiThread {
                        weatherTextView.text = "Temp: $temp°C
Description: $description"
                    }
                }
            }
        })
    }

    private fun updateHistory() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, cityHistory)
        historyList.adapter = adapter
    }
}
            